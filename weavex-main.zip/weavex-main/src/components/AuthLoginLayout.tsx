import { Link } from 'react-router-dom';
import { Loader2, LucideIcon } from 'lucide-react';
import { ReactNode } from 'react';

export type AuthLoginVariant = 'user' | 'admin';

export type AuthLoginLayoutProps = {
  /** Page title below the brand (e.g. "Sign in") */
  title: string;
  subtitle: string;
  headerIcon: LucideIcon;
  error: string | null;
  children: ReactNode;
  alternateLink?: { to: string; label: string };
  isLoading: boolean;
  variant?: AuthLoginVariant;
};

export function AuthLoginLayout({
  title,
  subtitle,
  headerIcon: HeaderIcon,
  error,
  children,
  alternateLink,
  isLoading,
  variant = 'user',
}: AuthLoginLayoutProps) {
  const accent =
    variant === 'admin'
      ? {
          ring: 'ring-rose-500/20',
          iconBg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400',
          link: 'text-indigo-600 hover:text-indigo-500 dark:text-indigo-400',
          badge: 'bg-rose-500/10 text-rose-700 dark:text-rose-300 border-rose-200/60 dark:border-rose-500/30',
        }
      : {
          ring: 'ring-indigo-500/20',
          iconBg: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400',
          link: 'text-indigo-600 hover:text-indigo-500 dark:text-indigo-400',
          badge: 'bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 border-indigo-200/60 dark:border-indigo-500/30',
        };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-indigo-400" />
          <p className="text-sm text-slate-400 font-medium tracking-wide">Weaves</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative flex flex-col items-center justify-center px-4 py-12 sm:px-6 overflow-hidden bg-slate-950">
      {/* Background */}
      <div
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(99,102,241,0.25),transparent)]"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute top-1/4 -left-32 h-96 w-96 rounded-full bg-indigo-600/20 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute bottom-0 right-0 h-80 w-80 rounded-full bg-violet-600/15 blur-3xl"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.15] bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"
        aria-hidden
      />

      <div className="relative w-full max-w-[440px]">
        {/* Brand */}
        <div className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">
            <span className="bg-gradient-to-r from-white via-indigo-100 to-violet-200 bg-clip-text text-transparent">
              Weaves
            </span>
          </h1>
          <p className="mt-2 text-sm text-slate-400 font-medium tracking-wide">
            Smart health monitoring
          </p>
        </div>

        <div
          className={`rounded-2xl border border-white/10 bg-white/[0.97] dark:bg-slate-900/90 backdrop-blur-xl shadow-2xl shadow-black/40 p-8 sm:p-10 ring-1 ${accent.ring}`}
        >
          <div className="text-center">
            <div
              className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl ${accent.iconBg} ring-1 ring-black/5 dark:ring-white/10`}
            >
              <HeaderIcon className="h-7 w-7" strokeWidth={1.75} />
            </div>
            <span
              className={`mt-4 inline-flex items-center rounded-full border px-3 py-0.5 text-xs font-semibold uppercase tracking-wider ${accent.badge}`}
            >
              {variant === 'admin' ? 'Administrator' : 'Member'}
            </span>
            <h2 className="mt-4 text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              {title}
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              {subtitle}
            </p>
          </div>

          {error && (
            <div
              role="alert"
              className="mt-6 rounded-xl border border-red-200/80 bg-red-50 dark:bg-red-950/40 dark:border-red-500/30 px-4 py-3 text-sm text-red-800 dark:text-red-200"
            >
              {error}
            </div>
          )}

          <div className="mt-8">{children}</div>

          {alternateLink && (
            <p className="mt-8 text-center text-sm text-slate-500 dark:text-slate-400">
              <Link
                to={alternateLink.to}
                className={`font-semibold ${accent.link} transition-colors`}
              >
                {alternateLink.label}
              </Link>
            </p>
          )}
        </div>

        <p className="mt-8 text-center text-xs text-slate-500 dark:text-slate-500">
          © {new Date().getFullYear()} Weaves. All rights reserved.
        </p>
      </div>
    </div>
  );
}
