import { ReactNode, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { 
  LayoutDashboard, 
  Activity, 
  HeartPulse, 
  History, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Moon,
  Sun,
  Languages,
  ChevronRight,
  User
} from 'lucide-react';
import { clsx } from 'clsx';
import { motion, AnimatePresence } from 'framer-motion';

export default function Layout({ children }: { children: ReactNode }) {
  const { t, language, setLanguage } = useLanguage();
  const { isDark, toggleTheme } = useTheme();
  const { userData, logout } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  if (location.pathname === '/login' || location.pathname === '/admin/login') return <>{children}</>;

  const navItems = [
    { path: '/dashboard', icon: LayoutDashboard, label: t.dashboard, end: true },
    { path: '/dashboard/stress', icon: Activity, label: t.stressMonitoring, end: false },
    { path: '/dashboard/ecg', icon: HeartPulse, label: t.ecgMonitoring, end: false },
    { path: '/dashboard/history', icon: History, label: t.history, end: false },
    { path: '/dashboard/settings', icon: Settings, label: t.settings, end: false },
  ];

  const sidebarVariants: any = {
    open: { x: 0, opacity: 1, transition: { type: "spring", stiffness: 300, damping: 30 } },
    closed: { x: "-100%", opacity: 0, transition: { type: "spring", stiffness: 300, damping: 30 } },
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 transition-colors duration-300 font-sans selection:bg-indigo-500/30">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md sticky top-0 z-30 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-bold text-slate-900 dark:text-white">{t.appTitle}</h1>
        </div>
        <button onClick={() => setIsSidebarOpen(true)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      <div className="flex h-screen overflow-hidden">
        {/* Sidebar Backdrop (Mobile) */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40"
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <motion.aside 
          variants={sidebarVariants}
          initial="closed"
          animate={isSidebarOpen || window.innerWidth >= 1024 ? "open" : "closed"}
          className={clsx(
            "fixed lg:static inset-y-0 left-0 z-50 w-72 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col shadow-2xl lg:shadow-none",
            "lg:translate-x-0"
          )}
        >
          <div className="p-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 dark:text-white leading-none">Weave<span className="text-indigo-500">X</span></h1>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium">Smart Arm Sleeve</p>
              </div>
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  end={item.end}
                  onClick={() => setIsSidebarOpen(false)}
                  className={({ isActive }) => clsx(
                    "group flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200",
                    isActive 
                      ? "bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 font-semibold shadow-sm ring-1 ring-indigo-200 dark:ring-indigo-500/20" 
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700/50 hover:text-slate-900 dark:hover:text-slate-200"
                  )}
                >
                  {({ isActive }) => (
                    <>
                      <div className="flex items-center gap-3">
                        <item.icon
                          className={clsx(
                            'w-5 h-5 transition-colors',
                            isActive
                              ? 'text-indigo-600 dark:text-indigo-400'
                              : 'text-slate-400 group-hover:text-slate-600'
                          )}
                        />
                        <span>{item.label}</span>
                      </div>
                      {isActive && (
                        <motion.div layoutId="active-nav" className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-indigo-400" />
                      )}
                    </>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>

          <div className="mt-auto p-6 border-t border-slate-200 dark:border-slate-700 space-y-4 bg-slate-50/50 dark:bg-slate-800/50">
            {/* User Profile Snippet */}
            <div className="flex items-center gap-3 px-2 py-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center">
                <User className="w-4 h-4 text-slate-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 dark:text-white truncate">@{userData?.username || 'Guest'}</p>
                <p className="text-xs text-slate-500 truncate capitalize">{userData?.role || 'User'}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={toggleTheme}
                className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:border-indigo-300 dark:hover:border-indigo-500 transition-colors"
              >
                {isDark ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
                <span className="text-xs font-medium">{isDark ? 'Dark' : 'Light'}</span>
              </button>

              <div className="relative group">
                <button className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:border-indigo-300 dark:hover:border-indigo-500 transition-colors">
                  <Languages className="w-4 h-4 text-slate-500" />
                  <span className="text-xs font-medium uppercase">{language}</span>
                </button>
                
                <div className="absolute bottom-full left-0 w-48 mb-2 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 overflow-hidden hidden group-hover:block z-50">
                  {(['en', 'es', 'hi', 'hr'] as const).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => setLanguage(lang)}
                      className={clsx(
                        "w-full text-left px-4 py-2.5 text-sm hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center justify-between",
                        language === lang && "bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400 font-medium"
                      )}
                    >
                      <span>
                        {lang === 'en' && 'English'}
                        {lang === 'es' && 'Español'}
                        {lang === 'hi' && 'हिंदी'}
                        {lang === 'hr' && 'हरियाणवी'}
                      </span>
                      {language === lang && <ChevronRight className="w-3 h-3" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button 
              onClick={() => {
                logout();
                navigate('/login');
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors text-sm font-medium border border-transparent hover:border-red-200 dark:hover:border-red-900/50"
            >
              <LogOut className="w-4 h-4" />
              <span>{t.logout}</span>
            </button>
          </div>
        </motion.aside>

        {/* Main Content Area */}
        <main className="flex-1 h-screen overflow-y-auto bg-slate-50 dark:bg-slate-900 relative">
          {/* Top decorative gradient */}
          <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-b from-indigo-50/50 to-transparent dark:from-indigo-900/10 pointer-events-none" />
          
          <div className="relative max-w-7xl mx-auto p-4 lg:p-8 pb-24">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
