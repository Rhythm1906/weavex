/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_THINGSPEAK_CHANNEL_ID?: string;
  readonly VITE_THINGSPEAK_READ_KEY?: string;
  readonly VITE_THINGSPEAK_WRITE_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
