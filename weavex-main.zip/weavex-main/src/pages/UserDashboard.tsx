import React from 'react';
import { Outlet } from 'react-router-dom';
import Layout from '../components/Layout';

/** User mode: full WeaveX sensor UI (ThingSpeak) with shared Layout. */
export const UserDashboard: React.FC = () => {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
};
