import { useLanguage } from '../context/LanguageContext';
import { useData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';
import { RadialBarChart, RadialBar, ResponsiveContainer } from 'recharts';
import { HeartPulse } from 'lucide-react';

export default function ECGMonitoring() {
  const { t } = useLanguage();
  const { isDark } = useTheme();
  const { latestData, isConnected } = useData();

  const ecgValue = parseFloat(latestData?.field5 || '0');
  // Assuming 10-bit ADC (0-1024) for normalization, or just use 100 if it's pre-processed
  // If the value is raw ADC, it might be around 300-600. Let's assume a max of 1024.
  const maxVal = 1024; 
  const normalizedValue = Math.min((ecgValue / maxVal) * 100, 100);

  const ecgData = [
    { name: 'ECG', value: normalizedValue, fill: '#f43f5e' },
    { name: 'Max', value: 100 - normalizedValue, fill: isDark ? '#374151' : '#e5e7eb' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
          <HeartPulse className="w-8 h-8 text-rose-500" />
          {t.ecgMonitoring}
        </h2>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-rose-400 via-rose-500 to-rose-600" />
        
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-rose-100 dark:bg-rose-900/30 rounded-full">
            <HeartPulse className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          </div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">Current ECG Value</h3>
        </div>

        <div className="h-[300px] w-full relative">
          <ResponsiveContainer width="100%" height="100%">
            <RadialBarChart 
              cx="50%" 
              cy="50%" 
              innerRadius="70%" 
              outerRadius="100%" 
              barSize={30} 
              data={ecgData} 
              startAngle={180} 
              endAngle={0}
            >
              <RadialBar
                background={{ fill: isDark ? '#1f2937' : '#f3f4f6' }}
                dataKey="value"
                cornerRadius={15}
              />
            </RadialBarChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center mt-12">
            <span className="text-6xl font-bold text-gray-900 dark:text-white font-mono">
              {isConnected ? ecgValue : '--'}
            </span>
            <span className="text-gray-500 dark:text-gray-400 font-medium mt-2">ADC Value</span>
          </div>
        </div>

        <div className="mt-8 text-center max-w-md">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="flex h-3 w-3 relative">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${isConnected ? 'bg-rose-400' : 'bg-gray-400'}`}></span>
              <span className={`relative inline-flex rounded-full h-3 w-3 ${isConnected ? 'bg-rose-500' : 'bg-gray-500'}`}></span>
            </span>
            <span className="text-sm font-medium text-gray-600 dark:text-gray-300">Live Sensor Feed</span>
          </div>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Displaying the instantaneous raw ECG sensor value.
          </p>
        </div>
      </div>
    </div>
  );
}
