import { useLanguage } from '../context/LanguageContext';
import { useData } from '../context/DataContext';
import { useState } from 'react';
import { format } from 'date-fns';

export default function History() {
  const { t } = useLanguage();
  const { data } = useData();
  const [filter, setFilter] = useState<'all' | 'hr' | 'stress'>('all');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t.history}</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${filter === 'all' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300'}`}
          >
            All
          </button>
          <button 
            onClick={() => setFilter('hr')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${filter === 'hr' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300'}`}
          >
            Heart Rate
          </button>
          <button 
            onClick={() => setFilter('stress')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${filter === 'stress' ? 'bg-indigo-600 text-white' : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300'}`}
          >
            Stress
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                <th className="px-6 py-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Timestamp</th>
                {(filter === 'all' || filter === 'hr') && (
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.heartRate} (BPM)</th>
                )}
                <th className="px-6 py-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.hrv} (ms)</th>
                {(filter === 'all' || filter === 'stress') && (
                  <th className="px-6 py-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.stressLevel}</th>
                )}
                <th className="px-6 py-4 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{t.gsr}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {data.slice().reverse().map((row, i) => (
                <tr key={i} className="hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400 font-mono">
                    {format(new Date(row.created_at), 'MMM dd, HH:mm:ss')}
                  </td>
                  {(filter === 'all' || filter === 'hr') && (
                    <td className="px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">
                      {row.field1}
                    </td>
                  )}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                    {row.field2}
                  </td>
                  {(filter === 'all' || filter === 'stress') && (
                    <td className="px-6 py-4 text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        parseFloat(row.field3) > 50 
                          ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' 
                          : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                      }`}>
                        {row.field3}
                      </span>
                    </td>
                  )}
                  <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                    {row.field4}
                  </td>
                </tr>
              ))}
              {data.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500 dark:text-gray-400">
                    {t.noData}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
