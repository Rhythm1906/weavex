import { useLanguage } from '../context/LanguageContext';
import { useData, SensorData } from '../context/DataContext';
import { useTheme } from '../context/ThemeContext';
import { motion } from 'framer-motion';
import { Activity, Heart, Zap, Droplets, AlertCircle, TrendingUp, Clock, Calendar, MoreHorizontal, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useState, useEffect } from 'react';
import { clsx } from 'clsx';
import { format, parseISO } from 'date-fns';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { t } = useLanguage();
  const { isDark } = useTheme();
  const { latestData, data: liveData, isConnected, config } = useData();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [timeRange, setTimeRange] = useState<'1h' | '6h' | '24h' | '7d'>('1h');
  const [chartData, setChartData] = useState<SensorData[]>([]);
  const [isChartLoading, setIsChartLoading] = useState(false);

  // Fetch chart data when timeRange or config changes
  useEffect(() => {
    const fetchChartData = async () => {
      if (!config.channelId) {
        setChartData([]);
        return;
      }

      setIsChartLoading(true);
      try {
        const params = new URLSearchParams();
        if (config.readApiKey.trim()) {
          params.set('api_key', config.readApiKey.trim());
        }

        if (timeRange === '1h') {
          params.set('results', '240');
        } else if (timeRange === '6h') {
          params.set('average', '5');
          params.set('results', '72');
        } else if (timeRange === '24h') {
          params.set('days', '1');
          params.set('average', '10');
        } else if (timeRange === '7d') {
          params.set('days', '7');
          params.set('average', '60');
        }

        const url = `https://api.thingspeak.com/channels/${config.channelId}/feeds.json?${params.toString()}`;
        const response = await fetch(url);
        const json = await response.json();
        
        if (json.feeds && Array.isArray(json.feeds)) {
          setChartData(json.feeds);
        }
      } catch (error) {
        console.error('Failed to fetch chart data:', error);
      } finally {
        setIsChartLoading(false);
      }
    };

    fetchChartData();
    
    // Set up polling for 1h view to keep it live-ish
    let interval: NodeJS.Timeout;
    if (timeRange === '1h') {
      interval = setInterval(fetchChartData, 15000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timeRange, config.channelId, config.readApiKey]);

  // Helper to parse float or return 0
  const getVal = (val: string | undefined) => val ? parseFloat(val) : 0;

  const heartRate = getVal(latestData?.field1);
  const hrv = getVal(latestData?.field2);
  const stress = getVal(latestData?.field3);
  const gsr = getVal(latestData?.field4);

  // Determine stress level label & color
  let stressLabel = t.stressLevels.low;
  let stressColor = "text-emerald-600 dark:text-emerald-400";
  let stressBg = "bg-emerald-100 dark:bg-emerald-900/30";
  let stressBorder = "border-emerald-200 dark:border-emerald-800";
  
  if (stress > 75) {
    stressLabel = t.stressLevels.extreme;
    stressColor = "text-rose-600 dark:text-rose-400";
    stressBg = "bg-rose-100 dark:bg-rose-900/30";
    stressBorder = "border-rose-200 dark:border-rose-800";
  } else if (stress > 50) {
    stressLabel = t.stressLevels.high;
    stressColor = "text-orange-600 dark:text-orange-400";
    stressBg = "bg-orange-100 dark:bg-orange-900/30";
    stressBorder = "border-orange-200 dark:border-orange-800";
  } else if (stress > 25) {
    stressLabel = t.stressLevels.moderate;
    stressColor = "text-amber-600 dark:text-amber-400";
    stressBg = "bg-amber-100 dark:bg-amber-900/30";
    stressBorder = "border-amber-200 dark:border-amber-800";
  }

  const StatCard = ({ title, value, unit, icon: Icon, colorClass, bgClass, trend, trendValue, subtext, delay }: any) => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 hover:shadow-md transition-all duration-300 group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-xl ${bgClass} group-hover:scale-110 transition-transform duration-300`}>
          <Icon className={`w-6 h-6 ${colorClass}`} />
        </div>
        {trend && (
          <div className={clsx("flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full", 
            trend === 'up' ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
          )}>
            {trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
            {trendValue}
          </div>
        )}
      </div>
      
      <div>
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">{title}</p>
        <div className="flex items-baseline gap-2">
          <h3 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            {isConnected ? value : '--'}
          </h3>
          <span className="text-sm font-medium text-slate-400">{unit}</span>
        </div>
      </div>
      
      {subtext && (
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700/50">
          {subtext}
        </div>
      )}
    </motion.div>
  );

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight">{t.dashboard}</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            {t.welcome}, <span className="font-medium text-indigo-600 dark:text-indigo-400">Admin</span>
          </p>
        </div>
        
        <div className="flex items-center gap-3 bg-white dark:bg-slate-800 p-1.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          {(['1h', '6h', '24h', '7d'] as const).map((range) => (
            <button
              key={range}
              onClick={() => setTimeRange(range)}
              className={clsx(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                timeRange === range 
                  ? "bg-indigo-600 text-white shadow-sm" 
                  : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700"
              )}
            >
              {range.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Connection Status Banner */}
      {!isConnected ? (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg shadow-indigo-500/20 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16" />
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/20 backdrop-blur-sm rounded-xl">
                <AlertCircle className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-bold">Device Disconnected</h3>
                <p className="text-indigo-100 opacity-90">{t.noData}</p>
              </div>
            </div>
            <Link
              to="/dashboard/settings"
              className="px-6 py-3 bg-white text-indigo-600 font-semibold rounded-xl shadow-sm hover:bg-indigo-50 transition-colors whitespace-nowrap"
            >
              Configure Device
            </Link>
          </div>
        </motion.div>
      ) : (
        <div className="flex items-center gap-2 text-sm font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-4 py-2 rounded-full w-fit border border-emerald-100 dark:border-emerald-800">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          System Online • Live Data Feed
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title={t.heartRate} 
          value={heartRate} 
          unit={t.bpm} 
          icon={Heart} 
          colorClass="text-rose-500" 
          bgClass="bg-rose-50 dark:bg-rose-500/10"
          trend="up"
          trendValue="+2%"
          delay={0.1}
          subtext={
            isConnected && heartRate > 100 ? (
              <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 text-sm font-medium bg-rose-50 dark:bg-rose-900/20 px-3 py-1.5 rounded-lg">
                <Activity className="w-4 h-4" />
                <span>Tachycardia Alert</span>
              </div>
            ) : (
              <div className="text-sm text-slate-500">Normal resting range</div>
            )
          }
        />
        <StatCard 
          title={t.hrv} 
          value={hrv} 
          unit={t.ms} 
          icon={Activity} 
          colorClass="text-violet-500" 
          bgClass="bg-violet-50 dark:bg-violet-500/10" 
          trend="down"
          trendValue="-5ms"
          delay={0.2}
          subtext={<div className="text-sm text-slate-500">Autonomic balance indicator</div>}
        />
        <StatCard 
          title={t.stressLevel} 
          value={stress} 
          unit={t.si} 
          icon={Zap} 
          colorClass={stressColor} 
          bgClass={stressBg}
          delay={0.3}
          subtext={
            isConnected && (
              <div className={`flex items-center gap-2 text-sm font-medium px-3 py-1.5 rounded-lg ${stressBg} ${stressColor} border ${stressBorder}`}>
                <div className={`w-2 h-2 rounded-full bg-current`} />
                <span>{stressLabel}</span>
              </div>
            )
          }
        />
        <StatCard 
          title={t.gsr} 
          value={gsr} 
          unit={t.uS} 
          icon={Droplets} 
          colorClass="text-cyan-500" 
          bgClass="bg-cyan-50 dark:bg-cyan-500/10" 
          delay={0.4}
          subtext={<div className="text-sm text-slate-500">Skin conductance level</div>}
        />
      </div>

      {/* Main Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Large Area Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">{t.recentTrends}</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">Heart Rate vs Stress Level</p>
            </div>
            <button className="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors">
              <MoreHorizontal className="w-5 h-5 text-slate-400" />
            </button>
          </div>
          
          <div className="h-[350px] w-full relative">
            {isChartLoading && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/50 dark:bg-slate-800/50 z-10 backdrop-blur-sm rounded-xl">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              </div>
            )}
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHr" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorStress" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? "#334155" : "#e2e8f0"} vertical={false} opacity={0.5} />
                <XAxis 
                  dataKey="created_at" 
                  tickFormatter={(str) => {
                    try {
                      const date = parseISO(str);
                      if (timeRange === '1h') return format(date, 'HH:mm');
                      if (timeRange === '6h') return format(date, 'HH:mm');
                      if (timeRange === '24h') return format(date, 'HH:mm');
                      return format(date, 'MMM dd');
                    } catch (e) {
                      return '';
                    }
                  }}
                  stroke={isDark ? "#94a3b8" : "#64748b"}
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  minTickGap={30}
                />
                <YAxis stroke={isDark ? "#94a3b8" : "#64748b"} fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#1e293b' : '#ffffff', 
                    borderRadius: '12px', 
                    border: isDark ? '1px solid #334155' : '1px solid #e2e8f0', 
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                    color: isDark ? '#f8fafc' : '#0f172a'
                  }}
                  itemStyle={{ color: isDark ? '#f8fafc' : '#0f172a' }}
                  labelFormatter={(label) => {
                    try {
                      const date = parseISO(label);
                      if (timeRange === '1h') return format(date, 'h:mm:ss a');
                      return format(date, 'MMM d, h:mm a');
                    } catch (e) {
                      return label;
                    }
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="field1" 
                  stroke="#f43f5e" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorHr)" 
                  name={t.heartRate} 
                  animationDuration={1500}
                />
                <Area 
                  type="monotone" 
                  dataKey="field3" 
                  stroke="#8b5cf6" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorStress)" 
                  name={t.stressLevel} 
                  animationDuration={1500}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Side Bar Chart */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700"
        >
          <div className="mb-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Stress Distribution</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400">Last 24 Hours</p>
          </div>

          <div className="h-[200px] w-full mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={(() => {
                if (!isConnected || liveData.length === 0) {
                  return [
                    { name: 'Low', value: 0, fill: '#10b981' },
                    { name: 'Mod', value: 0, fill: '#f59e0b' },
                    { name: 'High', value: 0, fill: '#f97316' },
                    { name: 'Ext', value: 0, fill: '#ef4444' },
                  ];
                }
                
                const counts = { low: 0, mod: 0, high: 0, ext: 0 };
                liveData.forEach(d => {
                  const val = parseFloat(d.field3 || '0');
                  if (val > 75) counts.ext++;
                  else if (val > 50) counts.high++;
                  else if (val > 25) counts.mod++;
                  else counts.low++;
                });

                return [
                  { name: 'Low', value: counts.low, fill: '#10b981' },
                  { name: 'Mod', value: counts.mod, fill: '#f59e0b' },
                  { name: 'High', value: counts.high, fill: '#f97316' },
                  { name: 'Ext', value: counts.ext, fill: '#ef4444' },
                ];
              })()}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDark ? "#334155" : "#e2e8f0"} opacity={0.5} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} fontSize={12} stroke={isDark ? "#94a3b8" : "#64748b"} />
                <Tooltip 
                  cursor={{ fill: 'transparent' }}
                  contentStyle={{ 
                    backgroundColor: isDark ? '#1e293b' : '#ffffff',
                    borderRadius: '8px', 
                    border: isDark ? '1px solid #334155' : '1px solid #e2e8f0',
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                    color: isDark ? '#f8fafc' : '#0f172a'
                  }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-3">
            {(() => {
              const total = liveData.length || 1; // Avoid division by zero
              const counts = { low: 0, mod: 0, high: 0, ext: 0 };
              if (isConnected && liveData.length > 0) {
                liveData.forEach(d => {
                  const val = parseFloat(d.field3 || '0');
                  if (val > 75) counts.ext++;
                  else if (val > 50) counts.high++;
                  else if (val > 25) counts.mod++;
                  else counts.low++;
                });
              }
              
              const getPct = (count: number) => isConnected && liveData.length > 0 ? Math.round((count / total) * 100) : 0;

              return (
                <>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                      <div className="w-2 h-2 rounded-full bg-emerald-500" />
                      Low Stress
                    </span>
                    <span className="font-semibold text-slate-900 dark:text-white">{getPct(counts.low)}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                      <div className="w-2 h-2 rounded-full bg-amber-500" />
                      Moderate
                    </span>
                    <span className="font-semibold text-slate-900 dark:text-white">{getPct(counts.mod)}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                      <div className="w-2 h-2 rounded-full bg-rose-500" />
                      High/Extreme
                    </span>
                    <span className="font-semibold text-slate-900 dark:text-white">{getPct(counts.high + counts.ext)}%</span>
                  </div>
                </>
              );
            })()}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
