import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, ShieldAlert, Users, Activity, LayoutDashboard } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AdminDashboard: React.FC = () => {
  const { userData, logout } = useAuth();
  const hasLocalAccount = typeof window !== 'undefined' && !!localStorage.getItem('weaves_account');

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <ShieldAlert className="h-8 w-8 text-red-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Admin Portal</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">@{userData?.username}</span>
              <span className="px-3 py-1 text-xs font-semibold text-red-800 bg-red-100 rounded-full uppercase tracking-wider">
                {userData?.role}
              </span>
              <button
                onClick={() => logout()}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 hover:text-gray-700 focus:outline-none transition"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white overflow-hidden shadow rounded-lg border border-gray-100">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-6 w-6 text-gray-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">Local accounts</dt>
                      <dd className="text-3xl font-semibold text-gray-900">{hasLocalAccount ? 1 : 0}</dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg border border-gray-100">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Activity className="h-6 w-6 text-gray-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">System Status</dt>
                      <dd className="text-lg font-semibold text-green-600 flex items-center mt-1">
                        <span className="w-2.5 h-2.5 bg-green-500 rounded-full mr-2"></span>
                        Local only (no server)
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 bg-white shadow rounded-lg border border-gray-100 p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Admin Controls</h3>
            <p className="text-gray-500 mb-4">
              Authentication is stored in this browser only. Use the member login to open the sensor dashboard.
            </p>
            <Link
              to="/dashboard"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              <LayoutDashboard className="h-4 w-4" />
              Open sensor dashboard
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
};
