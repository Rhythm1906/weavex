import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ShieldAlert, Loader2, User, Lock } from 'lucide-react';
import { AuthLoginLayout } from '../components/AuthLoginLayout';

const inputClass =
  'w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-800/80 py-3 pl-11 pr-4 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 shadow-sm transition-all focus:border-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-400/20 dark:focus:border-slate-500';

export const AdminLogin: React.FC = () => {
  const { user, userData, loginWithUsername, loading } = useAuth();
  const navigate = useNavigate();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    if (!user || !userData || loading) return;
    navigate(userData.role === 'admin' ? '/admin' : '/dashboard', { replace: true });
  }, [user, userData, loading, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please enter both username and password.');
      return;
    }
    setIsSigningIn(true);
    setError(null);
    try {
      await loginWithUsername(username, password);
    } catch (err: unknown) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Failed to sign in. Please check your credentials.');
      setIsSigningIn(false);
    }
  };

  return (
    <AuthLoginLayout
      variant="admin"
      title="Administrator access"
      subtitle="Restricted area. Sign in with credentials issued to your organization."
      headerIcon={ShieldAlert}
      error={error}
      isLoading={loading}
      alternateLink={{ to: '/login', label: '← Back to member sign in' }}
    >
      <form className="space-y-5" onSubmit={handleLogin}>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Username
            </label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className={inputClass}
                placeholder="Administrator username"
              />
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={inputClass}
                placeholder="Enter your password"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSigningIn}
          className="mt-1 flex w-full items-center justify-center rounded-xl bg-slate-900 py-3 text-sm font-semibold text-white shadow-lg shadow-slate-900/30 transition-all hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 dark:focus:ring-offset-slate-900"
        >
          {isSigningIn ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Sign in securely'}
        </button>
      </form>
    </AuthLoginLayout>
  );
};
