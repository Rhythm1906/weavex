import { useLanguage } from '../context/LanguageContext';
import { useData } from '../context/DataContext';
import { RadialBarChart, RadialBar, Legend, ResponsiveContainer, Tooltip } from 'recharts';
import { Zap, Droplets } from 'lucide-react';

export default function StressMonitoring() {
  const { t } = useLanguage();
  const { latestData, isConnected } = useData();

  const stress = parseFloat(latestData?.field3 || '0');
  const gsr = parseFloat(latestData?.field4 || '0');

  // Gauge data
  const stressData = [
    { name: 'Stress', value: stress, fill: '#8b5cf6' },
    { name: 'Max', value: 100 - stress, fill: '#e5e7eb' }
  ];

  let stressStatus = t.stressLevels.low;
  if (stress > 75) stressStatus = t.stressLevels.extreme;
  else if (stress > 50) stressStatus = t.stressLevels.high;
  else if (stress > 25) stressStatus = t.stressLevels.moderate;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{t.stressMonitoring}</h2>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Stress Gauge */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-green-400 via-yellow-400 to-red-500" />
          
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-violet-100 dark:bg-violet-900/30 rounded-full">
              <Zap className="w-6 h-6 text-violet-600 dark:text-violet-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t.stressLevel}</h3>
          </div>

          <div className="h-[250px] w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <RadialBarChart 
                cx="50%" 
                cy="50%" 
                innerRadius="70%" 
                outerRadius="100%" 
                barSize={20} 
                data={stressData} 
                startAngle={180} 
                endAngle={0}
              >
                <RadialBar
                  background
                  dataKey="value"
                  cornerRadius={10}
                />
              </RadialBarChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center mt-8">
              <span className="text-5xl font-bold text-gray-900 dark:text-white">
                {isConnected ? stress : '--'}
              </span>
              <span className="text-gray-500 dark:text-gray-400 font-medium mt-2">{t.si}</span>
            </div>
          </div>

          <div className="mt-4 text-center">
            <span className={`inline-block px-4 py-2 rounded-full text-sm font-bold ${
              stress > 50 
                ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400' 
                : 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
            }`}>
              {isConnected ? stressStatus : t.waitingForData}
            </span>
          </div>
        </div>

        {/* GSR Card */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-cyan-100 dark:bg-cyan-900/30 rounded-full">
              <Droplets className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">{t.gsr}</h3>
          </div>

          <div className="flex-1 flex flex-col items-center justify-center">
             <div className="text-center space-y-2">
               <h4 className="text-6xl font-light text-gray-900 dark:text-white">
                 {isConnected ? gsr : '--'}
               </h4>
               <p className="text-xl text-gray-500 dark:text-gray-400">{t.uS}</p>
             </div>
             
             <div className="mt-8 w-full bg-gray-100 dark:bg-gray-700 rounded-full h-4 overflow-hidden">
               <div 
                 className="h-full bg-cyan-500 transition-all duration-500"
                 style={{ width: `${Math.min(gsr, 100)}%` }}
               />
             </div>
             <p className="mt-4 text-sm text-gray-500 dark:text-gray-400 text-center">
               Galvanic Skin Response indicates physiological arousal.
             </p>
          </div>
        </div>
      </div>
    </div>
  );
}
