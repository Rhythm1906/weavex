import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Shield, Loader2, User, Lock } from 'lucide-react';
import { AuthLoginLayout } from '../components/AuthLoginLayout';

const inputClass =
  'w-full rounded-xl border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-800/80 py-3 pl-11 pr-4 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 shadow-sm transition-all focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20';

export const UserLogin: React.FC = () => {
  const { user, userData, loginWithUsername, registerWithUsername, loading } = useAuth();
  const navigate = useNavigate();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    if (!user || !userData || loading) return;
    navigate(userData.role === 'admin' ? '/admin' : '/dashboard', { replace: true });
  }, [user, userData, loading, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Please enter both username and password.');
      return;
    }
    setIsSigningIn(true);
    setError(null);
    try {
      await loginWithUsername(username, password);
    } catch (err: unknown) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Failed to sign in. Please check your credentials.');
      setIsSigningIn(false);
    }
  };

  const handleRegister = async () => {
    if (!username || !password) {
      setError('Please enter both username and password to register.');
      return;
    }
    if (username.length < 3) {
      setError('Username must be at least 3 characters long.');
      return;
    }
    setIsRegistering(true);
    setError(null);
    try {
      await registerWithUsername(username, password);
    } catch (err: unknown) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Failed to register. Please try again.');
      setIsRegistering(false);
    }
  };

  return (
    <AuthLoginLayout
      variant="user"
      title="Welcome back"
      subtitle="Sign in to continue to your workspace and wellness insights."
      headerIcon={Shield}
      error={error}
      isLoading={loading}
      alternateLink={{ to: '/admin/login', label: 'Administrator access →' }}
    >
      <form className="space-y-5" onSubmit={handleLogin}>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Username
            </label>
            <div className="relative">
              <User className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className={inputClass}
                placeholder="Enter your username"
              />
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Password
            </label>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
              <input
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={inputClass}
                placeholder="Enter your password"
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-3 pt-1">
          <button
            type="submit"
            disabled={isSigningIn || isRegistering}
            className="flex w-full items-center justify-center rounded-xl bg-indigo-600 py-3 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition-all hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:focus:ring-offset-slate-900"
          >
            {isSigningIn ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Sign in'}
          </button>
          <button
            type="button"
            onClick={handleRegister}
            disabled={isSigningIn || isRegistering}
            className="flex w-full items-center justify-center rounded-xl border border-slate-200 bg-white py-3 text-sm font-semibold text-slate-700 shadow-sm transition-all hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-slate-300 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 dark:focus:ring-offset-slate-900"
          >
            {isRegistering ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Create account'}
          </button>
        </div>
      </form>
    </AuthLoginLayout>
  );
};
