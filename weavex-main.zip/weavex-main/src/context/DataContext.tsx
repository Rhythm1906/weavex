import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';

export interface SensorData {
  created_at: string;
  field1: string; // Heart Rate
  field2: string; // HRV
  field3: string; // Stress Index
  field4: string; // GSR
  field5: string; // ECG
}

interface ServerConfig {
  channelId: string;
  readApiKey: string;
}

interface DataContextType {
  data: SensorData[];
  latestData: SensorData | null;
  config: ServerConfig;
  setConfig: (config: ServerConfig) => void;
  isConnected: boolean;
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<SensorData[]>([]);
  const [config, setConfigState] = useState<ServerConfig>(() => {
    const saved = localStorage.getItem('server_config');
    if (saved) return JSON.parse(saved) as ServerConfig;
    return {
      channelId: import.meta.env.VITE_THINGSPEAK_CHANNEL_ID || '12397',
      readApiKey: import.meta.env.VITE_THINGSPEAK_READ_KEY || '',
    };
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const setConfig = (newConfig: ServerConfig) => {
    setConfigState(newConfig);
    localStorage.setItem('server_config', JSON.stringify(newConfig));
  };

  const refreshData = useCallback(async () => {
    if (!config.channelId) return;

    setIsLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams({ results: '50' });
      if (config.readApiKey.trim()) {
        params.set('api_key', config.readApiKey.trim());
      }
      const url = `https://api.thingspeak.com/channels/${config.channelId}/feeds.json?${params.toString()}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to fetch data from server');
      }

      const json = await response.json();
      if (json.feeds && Array.isArray(json.feeds)) {
        setData(json.feeds);
        setIsConnected(true);
      } else {
        throw new Error('Invalid data format');
      }
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'Unknown error');
      setIsConnected(false);
    } finally {
      setIsLoading(false);
    }
  }, [config]);

  // Initial fetch and periodic polling
  useEffect(() => {
    if (config.channelId) {
      refreshData();
      const interval = setInterval(refreshData, 15000); // 15s limit
      return () => clearInterval(interval);
    }
  }, [config, refreshData]);

  const latestData = data.length > 0 ? data[data.length - 1] : null;

  return (
    <DataContext.Provider value={{ 
      data, 
      latestData, 
      config, 
      setConfig, 
      isConnected, 
      isLoading, 
      error,
      refreshData 
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
