import React, { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';

const SESSION_KEY = 'weaves_session';
const ACCOUNT_KEY = 'weaves_account';

export interface UserData {
  uid: string;
  username: string;
  role: 'admin' | 'user';
  createdAt: number;
}

interface AuthContextType {
  user: { username: string } | null;
  userData: UserData | null;
  loading: boolean;
  loginWithUsername: (username: string, pass: string) => Promise<void>;
  registerWithUsername: (username: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function roleForUsername(username: string): 'admin' | 'user' {
  return username.trim().toLowerCase() === 'admin' ? 'admin' : 'user';
}

function readSession(): UserData | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserData;
  } catch {
    return null;
  }
}

function writeSession(data: UserData) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(data));
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ username: string } | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = readSession();
    if (session) {
      setUserData(session);
      setUser({ username: session.username });
    }
    setLoading(false);
  }, []);

  const applySession = useCallback((username: string) => {
    const uname = username.trim();
    const role = roleForUsername(uname);
    const data: UserData = {
      uid: uname,
      username: uname,
      role,
      createdAt: Date.now(),
    };
    writeSession(data);
    setUserData(data);
    setUser({ username: uname });
  }, []);

  /** Password is not verified (local demo); any non-empty username + password signs you in. */
  const loginWithUsername = async (username: string, pass: string) => {
    const u = username.trim();
    if (!u || !pass) {
      throw new Error('Please enter username and password.');
    }
    applySession(u);
  };

  const registerWithUsername = async (username: string, password: string) => {
    const u = username.trim();
    if (!u) {
      throw new Error('Please enter a username.');
    }
    const account = { username: u, password };
    localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
    applySession(u);
  };

  const logout = async () => {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
    setUserData(null);
  };

  return (
    <AuthContext.Provider
      value={{ user, userData, loading, loginWithUsername, registerWithUsername, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};
